--Procedimiento almacenado de  Habitacion 
select * from Reserva_Producto
go 
CREATE PROCEDURE sp_actualizarTabla
    @tipoOrden NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @sql NVARCHAR(MAX)

    IF @tipoOrden = 'Disponible'
    BEGIN
        SET @sql = 'SELECT Habitacion.IdHabitacion, Habitacion.Numero_Habitacion, Estado_Hab.Nombre_Est, Tipo_Habitacion.Nombre_Hab
                    FROM Habitacion
                    JOIN Estado_Hab ON Habitacion.IdEstado = Estado_Hab.idEstado_Hab
                    JOIN Tipo_Habitacion ON Habitacion.IdTipo_Hab = Tipo_Habitacion.IdTipo_Hab
                    WHERE Estado_Hab.Nombre_Est = ''Disponible''
                    ORDER BY Estado_Hab.Nombre_Est DESC'
    END
    ELSE IF @tipoOrden = 'Mantenimiento'
    BEGIN
        SET @sql = 'SELECT Habitacion.IdHabitacion, Habitacion.Numero_Habitacion, Estado_Hab.Nombre_Est, Tipo_Habitacion.Nombre_Hab
                    FROM Habitacion
                    JOIN Estado_Hab ON Habitacion.IdEstado = Estado_Hab.idEstado_Hab
                    JOIN Tipo_Habitacion ON Habitacion.IdTipo_Hab = Tipo_Habitacion.IdTipo_Hab
                    WHERE Estado_Hab.Nombre_Est = ''Mantenimiento''
                    ORDER BY Estado_Hab.Nombre_Est DESC'
    END
    ELSE IF @tipoOrden = 'Reservado'
    BEGIN
        SET @sql = 'SELECT Habitacion.IdHabitacion, Habitacion.Numero_Habitacion, Estado_Hab.Nombre_Est, Tipo_Habitacion.Nombre_Hab
                    FROM Habitacion
                    JOIN Estado_Hab ON Habitacion.IdEstado = Estado_Hab.idEstado_Hab
                    JOIN Tipo_Habitacion ON Habitacion.IdTipo_Hab = Tipo_Habitacion.IdTipo_Hab
                    WHERE Estado_Hab.Nombre_Est = ''Reservado''
                    ORDER BY Estado_Hab.Nombre_Est DESC'
    END
    ELSE
    BEGIN
        SET @sql = 'SELECT Habitacion.IdHabitacion, Habitacion.Numero_Habitacion, Estado_Hab.Nombre_Est, Tipo_Habitacion.Nombre_Hab
                    FROM Habitacion
                    JOIN Estado_Hab ON Habitacion.IdEstado = Estado_Hab.idEstado_Hab
                    JOIN Tipo_Habitacion ON Habitacion.IdTipo_Hab = Tipo_Habitacion.IdTipo_Hab
                    ORDER BY Estado_Hab.Nombre_Est DESC'
    END

    EXEC sp_executesql @sql
END



--Procedimiento almacenado de llenar datos  en la tabla 


CREATE PROCEDURE sp_llenarDatosEnModelo
AS
BEGIN
    SET NOCOUNT ON;

    SELECT Numero_Habitacion, Nombre_Est, Nombre_Hab
    FROM Habitacion
    JOIN Estado_Hab ON Habitacion.IdEstado = Estado_Hab.idEstado_Hab
    JOIN Tipo_Habitacion ON Habitacion.IdTipo_Hab = Tipo_Habitacion.IdTipo_Hab
END



