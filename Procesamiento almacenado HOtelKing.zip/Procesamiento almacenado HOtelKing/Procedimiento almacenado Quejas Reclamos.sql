----------------Quejas y reclamos 

CREATE PROCEDURE sp_listarReportes
AS
BEGIN
    SET NOCOUNT ON;

    SELECT IdReporte, Descripcion, Estado_Reporte, Tipo_Reporte
    FROM Quejas_Reclamos;
END


go 

CREATE PROCEDURE sp_insertarReporte
    @tipoReporte NVARCHAR(255),
    @descripcion NVARCHAR(MAX),
    @estado NVARCHAR(255)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Quejas_Reclamos(Tipo_Reporte, Descripcion, Estado_Reporte, Fecha_Reporte)
    VALUES (@tipoReporte, @descripcion, @estado, GETDATE());
END


