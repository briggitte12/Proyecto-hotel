-----------Procedimiento almacenado para Cliene DAO 

CREATE PROCEDURE dbo.sp_guardarDatosClienteReserva
    @nombres NVARCHAR(255),
    @apellidoPat NVARCHAR(255),
    @apellidoMat NVARCHAR(255),
    @tipoDocumento NVARCHAR(50),
    @numeroDoc NVARCHAR(50),
    @fechaIngreso DATE,
    @fechaSalida DATE
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @idCliente INT;
    DECLARE @idReserva INT;
    DECLARE @idHabitacionSeleccionada INT;

    -- Insertar datos en la tabla Cliente
    INSERT INTO dbo.Cliente (NombreCli, ApellidoPat_Cli, ApellidoMat_Cli, TipoDocumento, NumeroDoc)
    VALUES (@nombres, @apellidoPat, @apellidoMat, @tipoDocumento, @numeroDoc);

    -- Obtener el ID del cliente reci�n insertado
    SET @idCliente = SCOPE_IDENTITY();

    -- Insertar datos en la tabla Reserva, utilizando IdCliente
    INSERT INTO dbo.Reserva (IdCliente, Fecha_Ingreso, Fecha_Salida)
    VALUES (@idCliente, @fechaIngreso, @fechaSalida);

    -- Obtener el ID de la reserva reci�n insertada
    SET @idReserva = SCOPE_IDENTITY();

    -- Obtener el ID de la habitaci�n seleccionada (modificado para recibir par�metros si es necesario)
    SET @idHabitacionSeleccionada = dbo.obtenerIdHabitacionSeleccionada();

    IF @idHabitacionSeleccionada IS NOT NULL
    BEGIN
        -- Asignar la reserva a la habitaci�n seleccionada
        UPDATE dbo.Habitacion
        SET IdReserva = @idReserva
        WHERE IdHabitacion = @idHabitacionSeleccionada;

        -- Actualizar el estado de la habitaci�n a "Reservado"
        UPDATE dbo.Estado_Hab
        SET Nombre_Est = 'Reservado'
        WHERE IdEstado_Hab = (SELECT IdEstado FROM dbo.Habitacion WHERE IdHabitacion = @idHabitacionSeleccionada);

        -- Notificar al usuario que los datos se han guardado correctamente
        PRINT 'Los datos se han guardado correctamente en la base de datos';
    END
    ELSE
    BEGIN
        -- Manejar el caso en el que no se ha seleccionado una habitaci�n
        PRINT 'No se ha seleccionado una habitaci�n';
    END
END


go
SELECT *
FROM INFORMATION_SCHEMA.ROUTINES
WHERE ROUTINE_NAME = 'guardarDatosClienteReserva';


go

CREATE PROCEDURE sp_insertarReserva
    @idCliente INT,
    @fechaIngreso DATE,
    @fechaSalida DATE
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Reserva (IdCliente, Fecha_Ingreso, Fecha_Salida)
    VALUES (@idCliente, @fechaIngreso, @fechaSalida);

    SELECT SCOPE_IDENTITY() AS IdReserva; -- Devolver el ID generado
END



go 




CREATE PROCEDURE sp_actualizarEstadoHabitacion
    @idReserva INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Actualizar el IdEstado de la habitaci�n a "Reservado"
    UPDATE Habitacion
    SET IdEstado = 1
    WHERE IdReserva = @idReserva;
END


go 



CREATE PROCEDURE sp_asignarReservaAHabitacion
    @idReserva INT,
    @idHabitacionSeleccionada INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Verificar si la habitaci�n seleccionada est� disponible
    IF EXISTS (SELECT IdReserva FROM Habitacion WHERE IdHabitacion = @idHabitacionSeleccionada AND IdReserva IS NULL)
    BEGIN
        -- Actualizar la reserva en la habitaci�n seleccionada
        UPDATE Habitacion
        SET IdReserva = @idReserva
        WHERE IdHabitacion = @idHabitacionSeleccionada;

        -- Notificar al usuario que la reserva se asign� a la habitaci�n
        PRINT 'Reserva asignada a la habitaci�n correctamente';
    END
    ELSE
    BEGIN
        -- Notificar al usuario que la habitaci�n seleccionada no est� disponible
        PRINT 'La habitaci�n seleccionada no est� disponible para asignar la reserva';
    END
END



go 




CREATE PROCEDURE sp_obtenerDatosClientesReservas
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        Cliente.NombreCli,
        Cliente.ApellidoPat_Cli,
        Cliente.ApellidoMat_Cli,
        Cliente.TipoDocumento,
        Cliente.NumeroDoc,
        Reserva.Fecha_Ingreso,
        Reserva.Fecha_Salida
    FROM
        Cliente
    INNER JOIN
        Reserva ON Cliente.IdCliente = Reserva.IdCliente;
END



go 



CREATE PROCEDURE sp_eliminarClienteYReserva
    @idCliente INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Eliminar reserva por el ID del cliente
    DELETE FROM Reserva WHERE IdCliente = @idCliente;

    -- Eliminar cliente por su ID
    DELETE FROM Cliente WHERE IdCliente = @idCliente;
END
