-------------Login-----------

CREATE PROCEDURE sp_ValidarCredenciales
    @Usuario NVARCHAR(50),
    @Contrasena NVARCHAR(50)
AS
BEGIN
    SELECT Usuario, Nombre_Emp
    FROM Empleado
    WHERE Usuario = @Usuario AND contrasena = @Contrasena;
END
