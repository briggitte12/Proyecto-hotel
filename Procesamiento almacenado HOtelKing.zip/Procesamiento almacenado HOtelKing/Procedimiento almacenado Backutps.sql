-----------COPIA DE SEGURIDAD------


CREATE PROCEDURE sp_HotelKing
AS
BEGIN
    DECLARE @BackupPath NVARCHAR(255);
    DECLARE @BackupName NVARCHAR(255);

    SET @BackupPath = 'C:\Backup\';
    SET @BackupName = @BackupPath + 'HotelKing_Backup_' + 
                      REPLACE(CONVERT(NVARCHAR(20), GETDATE(), 120), ':', '') + '.bak';

    BACKUP DATABASE HotelKing TO DISK = @BackupName WITH INIT, STATS = 10;
END




