use HotelKing 


CREATE PROCEDURE uds_GuardarEmpleado
  @Nombre nvarchar(50),
  @ApellidoPat nvarchar(50),
  @ApellidoMat nvarchar(50),
  @FechaNac date,
  @Direccion nvarchar(255),
  @Estado nvarchar(50),
  @Login nvarchar(50),
  @Contrasena nvarchar(50),
  @Telefono nvarchar(50)
AS
BEGIN
  INSERT INTO Empleado (
  Nombre_Emp, Apellido_Pat_emp, Apellido_Mat_emp, fechaNac_Emp,
  Direccion, Estado_Emp, Usuario, Contrasena, Telefono) 
  VALUES (@Nombre, @ApellidoPat, @ApellidoMat, @FechaNac, @Direccion, 
  @Estado, @Login, @Contrasena, @Telefono);

  SELECT SCOPE_IDENTITY() AS Idempleado;
END
GO

