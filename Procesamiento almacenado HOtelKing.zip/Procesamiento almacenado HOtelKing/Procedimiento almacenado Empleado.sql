--------------Empleado-------------

CREATE PROCEDURE sp_actualizarTablaEmpleado
AS
BEGIN
    SET NOCOUNT ON;

    SELECT Nombre_Emp AS Nombre, 
           Apellido_Pat_emp AS 'Apellido Pat.', 
           Apellido_Mat_emp AS 'Apellido Mat.', 
           fechaNac_Emp AS 'Fecha Nac.', 
           Direccion, 
           Usuario AS 'Login', 
           Estado_Emp AS Estado 
    FROM Empleado;
END



go 


CREATE PROCEDURE sp_eliminarEmpleado
@idEmpleado INT
AS
BEGIN
    DELETE FROM Empleado WHERE IdEmpleado = @idEmpleado;
END
