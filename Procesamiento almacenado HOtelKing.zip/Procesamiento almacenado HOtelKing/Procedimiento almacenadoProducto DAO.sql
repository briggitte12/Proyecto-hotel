---------------Procedimiento almacenado de la clase Producto DAO 
GO 
CREATE PROCEDURE sp_obtenerNombre
    @codigo NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT Nombre_Prod
    FROM Producto
    WHERE IdProducto = @codigo
END

select * from Producto

GO 

CREATE PROCEDURE sp_obtenerPrecio
    @codigo NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT Precio_Prod
    FROM Producto
    WHERE IdProducto = @codigo
END


GO 


CREATE PROCEDURE sp_obtenerCategoria
    @codigo NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT Nombre_Cat
    FROM CategoriaProd
    WHERE IdCategoria_Prod = @codigo
END


GO 



CREATE PROCEDURE sp_guardarProducto
    @nombre NVARCHAR(255),
    @precio FLOAT,
    @habitacion NVARCHAR(255),
    @stock FLOAT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Producto (Nombre_Prod, Precio_prod, N_Item, Stock)
    VALUES (@nombre, @precio, @habitacion, @stock)
    
    SELECT 'Producto guardado correctamente' AS Mensaje
END

go 


CREATE PROCEDURE sp_cargarProductos
AS
BEGIN
    SET NOCOUNT ON;

    SELECT N_Item, Nombre_Prod, Precio_Prod, Stock
    FROM Producto
END
go 
SET IDENTITY_INSERT Reserva_Producto ON;

go
go
CREATE PROCEDURE sp_guardarReservaProducto
    @idReserva NVARCHAR(50),
    @nombre NVARCHAR(255),
    @cantidad FLOAT,
    @precioTotal FLOAT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Reserva_Producto (IdReserva_Prod, Nombre_Prod, Cantidad_Prod, PrecioTotal_Prod)
    VALUES (@idReserva, @nombre, @cantidad, @precioTotal);
END



go



CREATE PROCEDURE ObtenerCategoriaPorIdProducto
    @IdProducto INT
AS
BEGIN
    SELECT CategoriaProd.Nombre_Cat
    FROM Producto_Categoria
    JOIN CategoriaProd ON Producto_Categoria.IdCategoria = CategoriaProd.IdCategoria_prod
    WHERE Producto_Categoria.IdProducto = @IdProducto;
END;
